# NUCLE handover — 28/10/2026

Read reports/summaries/final/handover_checklist.md and the PDF/slides.
This bundle contains code and reviewed aggregates, no corpus, private audit text, checkpoints or per-sample predictions. Full training reproduction requires licensed local inputs. Historical source_manifest.json is a snapshot; use delivery_manifest.json for the updated report. Names/contributions/AI declarations need the group's confirmation; no submission is implied.
